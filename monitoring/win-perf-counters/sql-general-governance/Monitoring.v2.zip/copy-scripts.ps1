Copy-Item zip-logs.ps1 C:\PerfLogs\zip-logs.ps1
Copy-Item remove-old-logs.ps1 C:\PerfLogs\remove-old-logs.ps1