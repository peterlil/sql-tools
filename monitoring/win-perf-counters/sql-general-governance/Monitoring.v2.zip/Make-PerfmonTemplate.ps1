param ([string] $Servername, [string] $InstanceName = "", [string] $Template = "PerformanceMonitorTemplate_2012.xml")
$strarr = Get-Content $Template
	for ( $i = 0; $i -lt $strarr.Length; $i++ )
	{ 
		$strarr[$i] = ($strarr[$i] -replace "#SERVER#", $ServerName); 
		if($InstanceName.Length -ne 0 -and $InstanceName.ToLower() -ne "default") 
		{ 
			if($strarr[$i].Contains("SQLServer:SSIS") -eq $false)
			{
				$strarr[$i] = ($strarr[$i] -replace "SQLServer:", ([string]::Format('MSSQL${0}:', $InstanceName))); 
			}
		} 
	}
	Set-Content -Path ($Servername + "-PerfmonTemplate.xml") -Value $strarr